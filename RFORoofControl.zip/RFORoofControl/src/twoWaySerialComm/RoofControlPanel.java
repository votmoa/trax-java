/*

package twoWaySerialComm;



import java.awt.EventQueue;

import javax.swing.JFrame;



import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Window.Type;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import java.awt.Canvas;

public class RoofControlPanel {

	private JFrame frmRfoRoofControl;
	private JTextField textWeatherStatu;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	
	 	public static void roofControlPanel () {
		
		RoofControlPanel window = new RoofControlPanel();
		window.frmRfoRoofControl.setVisible(true);
				
	}

	
	public RoofControlPanel() {
		initialize();
	}

	
	private void initialize() {
		frmRfoRoofControl = new JFrame();
		frmRfoRoofControl.setResizable(false);
		frmRfoRoofControl.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 8));
		frmRfoRoofControl.getContentPane().setBackground(new Color(30, 144, 255));
		frmRfoRoofControl.setTitle("RFO ROOF CONTROL");
		frmRfoRoofControl.setBounds(100, 100, 450, 450);
		frmRfoRoofControl.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmRfoRoofControl.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("OPEN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TwoWaySerialComm.userInput = "L1";
				try{
    				SerialWriter.out.write(TwoWaySerialComm.userInput.getBytes());
    				}  catch (IOException ex) {}				
				System.out.println("I clicked OPEN");
				
			}
		});
		btnNewButton.setBounds(173, 187, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CLOSE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(303, 187, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Emerg STOP");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(173, 221, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Mount Pwr ON");
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.setBounds(173, 289, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnNewButton_3);
		
		JButton btnRoofPwrOn = new JButton("Roof Pwr ON");
		btnRoofPwrOn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnRoofPwrOn.setBounds(173, 255, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnRoofPwrOn);
		
		JButton btnRoofPwrOff = new JButton("Roof Pwr OFF");
		btnRoofPwrOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnRoofPwrOff.setBounds(303, 255, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnRoofPwrOff);
		
		JButton btnStatus = new JButton("STATUS");
		btnStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnStatus.setBounds(303, 221, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnStatus);
		
		JButton btnMountPwrOff = new JButton("Mount Pwr OFF");
		btnMountPwrOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnMountPwrOff.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnMountPwrOff.setBounds(303, 289, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnMountPwrOff);
		
		JButton btnOverrideOn = new JButton("Override ON");
		btnOverrideOn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnOverrideOn.setBounds(173, 323, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnOverrideOn);
		
		JButton btnOverrideOff = new JButton("Override OFF");
		btnOverrideOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnOverrideOff.setBounds(303, 323, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnOverrideOff);
		
		JButton btnDebugOn = new JButton("Debug ON");
		btnDebugOn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDebugOn.setBounds(173, 357, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnDebugOn);
		
		JButton btnDebugOff = new JButton("Debug OFF");
		btnDebugOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDebugOff.setBounds(303, 357, 105, 23);
		frmRfoRoofControl.getContentPane().add(btnDebugOff);
		
		
		JTextArea textArea = new JTextArea();
		textArea.setBackground(Color.YELLOW);
		textArea.setBounds(69, 60, 309, 60);
		frmRfoRoofControl.getContentPane().add(textArea);
		
		JLabel lblNewLabel = new JLabel("CCD System Status / Message");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(69, 35, 187, 14);
		frmRfoRoofControl.getContentPane().add(lblNewLabel);
		
		
		JLabel label_6 = new JLabel("Weather");
		label_6.setHorizontalTextPosition(SwingConstants.RIGHT);
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setBounds(20, 164, 53, 14);
		frmRfoRoofControl.getContentPane().add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setText("GOOD");
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_6.setColumns(4);
		textField_6.setBackground(Color.GREEN);
		textField_6.setBounds(77, 160, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField_6);
		
		
		JLabel lblWeather = new JLabel("Weather");
		lblWeather.setHorizontalTextPosition(SwingConstants.RIGHT);
		lblWeather.setHorizontalAlignment(SwingConstants.RIGHT);
		lblWeather.setBounds(20, 195, 53, 14);
		frmRfoRoofControl.getContentPane().add(lblWeather);
		
		textWeatherStatu = new JTextField();
		textWeatherStatu.setFont(new Font("Tahoma", Font.BOLD, 11));
		textWeatherStatu.setText("GOOD");
		textWeatherStatu.setBackground(Color.GREEN);
		textWeatherStatu.setHorizontalAlignment(SwingConstants.CENTER);
		textWeatherStatu.setColumns(4);
		textWeatherStatu.setBounds(77, 191, 61, 20);
		frmRfoRoofControl.getContentPane().add(textWeatherStatu);
		

		
		JLabel label = new JLabel("Weather");
		label.setHorizontalTextPosition(SwingConstants.RIGHT);
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(20, 226, 53, 14);
		frmRfoRoofControl.getContentPane().add(label);
		
		textField = new JTextField();
		textField.setText("GOOD");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField.setColumns(4);
		textField.setBackground(Color.GREEN);
		textField.setBounds(77, 222, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField);
		
		JLabel label_1 = new JLabel("Weather");
		label_1.setHorizontalTextPosition(SwingConstants.RIGHT);
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(20, 255, 53, 14);
		frmRfoRoofControl.getContentPane().add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setText("GOOD");
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_1.setColumns(4);
		textField_1.setBackground(Color.GREEN);
		textField_1.setBounds(77, 251, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField_1);
		
		JLabel label_2 = new JLabel("Weather");
		label_2.setHorizontalTextPosition(SwingConstants.RIGHT);
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setBounds(20, 284, 53, 14);
		frmRfoRoofControl.getContentPane().add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setText("GOOD");
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_2.setColumns(4);
		textField_2.setBackground(Color.GREEN);
		textField_2.setBounds(77, 280, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField_2);
		
		JLabel label_3 = new JLabel("Weather");
		label_3.setHorizontalTextPosition(SwingConstants.RIGHT);
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setBounds(20, 313, 53, 14);
		frmRfoRoofControl.getContentPane().add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setText("GOOD");
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_3.setColumns(4);
		textField_3.setBackground(Color.GREEN);
		textField_3.setBounds(77, 309, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField_3);
		
		JLabel label_4 = new JLabel("Weather");
		label_4.setHorizontalTextPosition(SwingConstants.RIGHT);
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setBounds(20, 342, 53, 14);
		frmRfoRoofControl.getContentPane().add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setText("GOOD");
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_4.setColumns(4);
		textField_4.setBackground(Color.GREEN);
		textField_4.setBounds(77, 338, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField_4);
		
		JLabel label_5 = new JLabel("Weather");
		label_5.setHorizontalTextPosition(SwingConstants.RIGHT);
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setBounds(20, 371, 53, 14);
		frmRfoRoofControl.getContentPane().add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setText("GOOD");
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		textField_5.setColumns(4);
		textField_5.setBackground(Color.GREEN);
		textField_5.setBounds(77, 367, 61, 20);
		frmRfoRoofControl.getContentPane().add(textField_5);
		

	}
}  

*/
